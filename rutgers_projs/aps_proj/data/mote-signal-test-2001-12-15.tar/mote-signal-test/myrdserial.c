
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>

#define BAUDRATE B19200
#define MODEMDEVICE "/dev/ttyS0"
#define _POSIX_SOURCE 1 /* POSIX compliant source */

#define TRUE 1
#define FALSE 0
#define DATA_LENGTH 86

volatile int STOP=FALSE; 

int process_lowbyte(char chr) {
   int num=0;

   if ((unsigned int) chr & 0x00000001) {
     num += 1;	
     /*printf("First bit set\n");*/
   }
   if ((unsigned int) chr & 0x00000002) {
     /*printf("Second bit set\n");*/
     num += 2;
   }
   if ((unsigned int) chr & 0x00000004) {
     /*printf("Third bit set\n");*/
     num += 4;
   }
   if ((unsigned int) chr & 0x00000008) {
     /*printf("Fourth bit set\n");*/
     num += 8;
   }
   if ((unsigned int) chr & 0x00000010) {
     /*printf("Fifth bit set\n");*/
     num += 16;
   }
   if ((unsigned int) chr & 0x00000020) {
     /*printf("Sixth bit set\n");*/
     num += 32;
   }
   if ((unsigned int) chr & 0x00000040) {
     /*printf("Seventh bit set\n");*/
     num += 64;
   }
   if ((unsigned int) chr & 0x00000080) {
     /*printf("Eigth bit set\n");*/
     num += 128;
   }
   return num;
}

int process_highbyte(char chr) {
   int num=0;

   if ((unsigned int) chr & 0x00000001) {
     num += 256;
     /*printf("First bit set\n");*/
   }
   if ((unsigned int) chr & 0x00000002) {
     /*printf("Second bit set\n");*/
     num += 512;
   }
   if ((unsigned int) chr & 0x00000004) {
     /*printf("Third bit set\n");*/
     num += 1024;
   }
   if ((unsigned int) chr & 0x00000008) {
     /*printf("Fourth bit set\n");*/
     num += 2048;
   }
   if ((unsigned int) chr & 0x00000010) {
     /*printf("Fifth bit set\n");*/
     num += 4096;
   }
   if ((unsigned int) chr & 0x00000020) {
     /*printf("Sixth bit set\n");*/
     num += 8192;
   }
   if ((unsigned int) chr & 0x00000040) {
     /*printf("Seventh bit set\n");*/
     num += 16384;
   }
   if ((unsigned int) chr & 0x00000080) {
     /*printf("Eigth bit set\n");*/
     num += 32768;
   }
   return num;
}

main() {
  int fd,c, res,i,j;
  int bytenum; 
  struct termios oldtio,newtio;
  char buf[255];
  int count, strength, low, high;

  /*printf("opening device \n");*/
  fd = open(MODEMDEVICE, O_RDWR | O_NOCTTY ); 
  if (fd <0) {perror(MODEMDEVICE); exit(-1); }

  tcgetattr(fd,&oldtio); /* save current port settings */

  memset(&newtio, 0, sizeof(newtio));
  newtio.c_cflag = BAUDRATE |  CS8 | CLOCAL | CREAD;
  newtio.c_iflag = IGNPAR;
  newtio.c_oflag = 0;

  /* set input mode (non-canonical, no echo,...) */
  newtio.c_lflag = 0;
        
  newtio.c_cc[VTIME]    = 0;   /* inter-character timer unused */
  newtio.c_cc[VMIN]     = 1;   /* blocking read until 5 chars received */

  tcflush(fd, TCIFLUSH);
  tcsetattr(fd,TCSANOW,&newtio);

  /*printf("reading data \n");*/
  bytenum=0;
  count=0;
  while (STOP==FALSE) {       /* loop for input */
    memset(buf, 0, 255);    
    res = read(fd,buf,255);   
    /*printf("%d: ", bytenum);*/
    for (i=0; i< res; i++) {
      /*printf(" %x :", ((unsigned int) (buf[i])) & 0x000000FF);*/
      bytenum++;
      count++;
      if (count == 90){
 	/*printf("*%x*", ((unsigned int) (buf[i])) & 0x000000FF);*/	
	low=process_lowbyte(buf[i]);
	/*printf("lower byte = %d\n", low);*/
      }
      if (count == 91) {
       /* printf("*%x*", ((unsigned int) (buf[i])) & 0x000000FF);*/
        high=process_highbyte(buf[i]);
       /* printf("high byte = %d\n", high);*/
        printf("%d\n", low+high);
        fflush(stdout);
       
	count=0;
      }
    }
  }
  tcsetattr(fd,TCSANOW,&oldtio);
}
