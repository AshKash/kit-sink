#include <stdio.h>
#include <stdlib.h>

void process_file(FILE *fpin, FILE *fpout, int threshold) 
{
  char buffer[256];
  
  while (fgets(buffer, 256, fpin)) {
    if (atoi(buffer) > threshold)
      fprintf(fpout, "%s", buffer);
  } 
}


int main(int argc, char *argv[]) 
{
  FILE *fpin=NULL, *fpout=NULL;
  int threshold;

  if (argc != 4) {
    fprintf(stderr, "Usage: %s [input file] [output file] [threshold]\n", argv[0]);
    return -1;
  }
  
  if ( (fpin=fopen(argv[1], "r")) == NULL ) {
    fprintf(stderr, "Could not open input file %s\n", argv[1]);
    return -1;
  }
  
  if ( (fpout=fopen(argv[2], "w")) == NULL) {
    fprintf(stderr, "Could not open output file %s\n", argv[2]);
    return -1;
  }
  
  if ( (threshold=atoi(argv[3])) <= 0 ) {
    fprintf(stderr, "Threshold %s is not greater than zero\n", argv[3]);
    return -1;
  }
  
  process_file(fpin, fpout, threshold);
 
  return 0;
}

