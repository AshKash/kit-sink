function f = fact(n) % Function definition line
% FACT Factorial.    % H1 line
% FACT(N) returns the factorial of N, H! % Help text
% usually denoted by N!
% Put simply, FACT(N) is PROD(1:N).
f = prod(1:n);       % Function body
