function f = myfun(n)
f=610/(n^0.03);