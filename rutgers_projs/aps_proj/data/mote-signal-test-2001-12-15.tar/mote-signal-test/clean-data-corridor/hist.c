#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
FILE *fpin=NULL, *fpout=NULL;
char line[256];
int signal;
int cnt1=0, cnt2=0, cnt3=0, cnt4=0, cnt5=0, cnt6=0, cnt7=0, cnt8=0;
int cnt9=0, cnt10=0, cnt11=0, cnt12=0, cnt13=0, cnt14=0, cnt15=0, cnt16=0;


if (argc !=3) {
   fprintf(stderr, "Usage: %s [input file] [output file]\n", argv[0]);
   return -1;
}

if ( (fpin=fopen(argv[1], "r")) == NULL ) {
   fprintf(stderr, "Couldn't open input file %s\n", argv[1]);
   return -1;
}

if ( (fpout=fopen(argv[2], "w")) == NULL ) {
   fprintf(stderr, "Couldn't open output file %s\n", argv[2]);
   return -1;
}

while (fgets(line, 256, fpin)) {
   signal=atoi(line);

   if ( signal >= 460 && signal < 470 )
      cnt1++;
   else if ( signal >= 470 && signal < 480 )
      cnt2++;
   else if ( signal >= 480 && signal < 490 )
      cnt3++;
   else if ( signal >= 490 && signal < 500 )
      cnt4++;
   else if ( signal >= 500 && signal < 510 )
      cnt5++;
   else if ( signal >= 510 && signal < 520 )
      cnt6++;
   else if ( signal >= 520 && signal < 530 )
      cnt7++;
   else if ( signal >= 530 && signal < 540 )
      cnt8++;
   else if ( signal >= 540 && signal < 550 )
      cnt9++;
   else if ( signal >= 550 && signal < 560 )
      cnt10++;
   else if ( signal >= 560 && signal < 570 )
      cnt11++;
   else if ( signal >= 570 && signal < 580 )
      cnt12++;
   else if ( signal >= 580 && signal < 590 )
      cnt13++;
   else if ( signal >= 590 && signal < 600 )
      cnt14++;
   else if ( signal >= 600 && signal < 610 )
      cnt15++;
   else 
      cnt16++;
}
   
fprintf(fpout, "%d\n", cnt1);
fprintf(fpout, "%d\n", cnt2);
fprintf(fpout, "%d\n", cnt3);
fprintf(fpout, "%d\n", cnt4);
fprintf(fpout, "%d\n", cnt5);
fprintf(fpout, "%d\n", cnt6);
fprintf(fpout, "%d\n", cnt7);
fprintf(fpout, "%d\n", cnt8);
fprintf(fpout, "%d\n", cnt9);
fprintf(fpout, "%d\n", cnt10);
fprintf(fpout, "%d\n", cnt11);
fprintf(fpout, "%d\n", cnt12);
fprintf(fpout, "%d\n", cnt13);
fprintf(fpout, "%d\n", cnt14);
fprintf(fpout, "%d\n", cnt15);
fprintf(fpout, "%d\n", cnt16);

fclose(fpin);
fclose(fpout);

return 0;
}



